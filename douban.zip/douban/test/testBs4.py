# -*- coding = utf-8 -*-
# @Time : 2021/2/14 13:44
# @Author : Sunny_Yao
# @File : testBs4.py
# @Software: PyCharm


'''
BeautifulSoup将复杂的html文档转换成一个复杂的树形结构，每个节点都是pytho对象，虽有对象可以归纳为4lei

-Tag
-NavigableString
-Comment
'''

from bs4 import BeautifulSoup

file = open("./baidu.html", "rb")
html = file.read()
bs = BeautifulSoup(html, "html.parser")
# Tag 显示标签及其内容，但是每次只显示找到的第一个内容
# print(bs.title)
# print(bs.a)
# print(bs.head)
# print(bs.title.string)
#
# print(bs.a.attrs)

# print(bs)

# print(bs.a.string) #不包含注释符号


# 文档的遍历
# print(bs.head.contents[1])


# 文档的搜索
# 字符串过滤：查找与字符串完全匹配的neir
# t_list = bs.findAll("a")
# print(t_list)

# 使用正则表达式
import re

#
# t_list = bs.find_all(re.compile("a"))
# print(t_list)

# 方法：传入一个函数，根据函数的要求来搜索
t_list = bs.find_all(text=re.compile("\d"))

for item in t_list:
    print(item)
