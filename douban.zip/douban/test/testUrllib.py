# -*- coding = utf-8 -*-
# @Time : 2021/2/14 0:34
# @Author : Sunny_Yao
# @File : testUrllib.py
# @Software: PyCharm

import urllib.request


# 获取一个get请求
# response = urllib.request.urlopen("http://www.baidu.com")
# print(response.read().decode("utf-8"))  # 对获取到的网页源码进行utf-8解码

'''
# 获取一个post请求
import urllib.parse

data = bytes(urllib.parse.urlencode({"hello": "world"}), encoding="utf-8")
response = urllib.request.urlopen("https://httpbin.org/post", data=data)
print(response.read().decode("utf-8"))
'''

'''
# 超时处理
try:
    response = urllib.request.urlopen("https://httpbin.org/get",timeout=0.01)
    print(response.read().decode("utf-8"))
except urllib.error.URLError as e:
    print("time out!")
'''

'''
response = urllib.request.urlopen("https://baidu.com")
# print(response.status)
print(response.getheaders())
'''

url = "https://www.douban.com"
headers = {
    "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Mobile Safari/537.36"
}
data = bytes(urllib.parse.urlencode({"hello": "world"}), encoding="utf-8")
res = urllib.request.Request(url=url, headers=headers, data=data, method="POST")
response = urllib.request.urlopen(res)
print(response.read().decode("utf-8"))
