# -*- coding = utf-8 -*-
# @Time : 2021/2/16 0:05
# @Author : Sunny_Yao
# @File : testSqllite.py
# @Software: PyCharm
import sqlite3
#1.连接数据库
conn = sqlite3.connect("test.db")       #打开或创建数据库文件

print("Opened database successfully")